
#ifndef OPENGL_H
#define OPENGL_H

/**
 ******************************************************************************
 *
 *                   Nice header to include OpenGL Stuff
 *
 ******************************************************************************
 */

#ifdef __APPLE__
   #include <GLUT/glut.h>
#else
   #include <GL/glut.h>
#endif

#endif
