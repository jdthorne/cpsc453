If this is your first time downloading this model just unzip it into
a new folder under quake2\baseq2\players\ called bug.


This is a new rendition of the bug model. Should make it easier to 
develope additional skins. Put it in the same directory as the 
first one and replace it with this model,otherwise skins will not be
displayed properly.

I use the Quake2 model editor v0.83. I need to thank POP for the skin
he used Micrographx Picture publisher v 6.

I would like to thank the author of this model for a base to work with.
Bug model by Tatey
animation by Tatey
skin mesh by Tatey
Tatey on icq 4625768
email d.r.scott1-96@student.lboro.ac.uk

Any Comments:

					SuperTech@ammdac.com
 